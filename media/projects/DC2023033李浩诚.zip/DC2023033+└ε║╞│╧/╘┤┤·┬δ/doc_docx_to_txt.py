import os
import win32com.client
from docx import Document

def convert_doc_to_txt(doc_path, output_folder):
    word = win32com.client.Dispatch('Word.Application')
    doc = word.Documents.Open(doc_path)
    text_content = doc.Content.Text
    doc.Close()
    word.Quit()

    # 构造相应的txt文件名
    txt_filename = os.path.splitext(os.path.basename(doc_path))[0] + '.txt'
    txt_path = os.path.join(output_folder, txt_filename)

    with open(txt_path, 'w', encoding='utf-8') as txt_file:
        txt_file.write(text_content)

def convert_docx_to_txt(docx_path, output_folder):
    doc = Document(docx_path)
    text_content = [paragraph.text for paragraph in doc.paragraphs]

    # 构造相应的txt文件名
    txt_filename = os.path.splitext(os.path.basename(docx_path))[0] + '.txt'
    txt_path = os.path.join(output_folder, txt_filename)

    with open(txt_path, 'w', encoding='utf-8') as txt_file:
        txt_file.write('\n'.join(text_content))

def convert_all_docs_to_txt(input_folder, output_folder):
    # 确保输出文件夹存在
    os.makedirs(output_folder, exist_ok=True)

    success_count = 0

    # 遍历输入文件夹中的所有文件
    for filename in os.listdir(input_folder):
        if filename.endswith('.doc'):
            doc_path = os.path.join(input_folder, filename)
            try:
                # 转换并保存为txt文件
                convert_doc_to_txt(doc_path, output_folder)
                print(f"Converted: {doc_path} -> {os.path.join(output_folder, os.path.splitext(filename)[0] + '.txt')}")
                success_count += 1
            except Exception as e:
                print(f"Error converting {doc_path}: {e}")

        elif filename.endswith('.docx'):
            docx_path = os.path.join(input_folder, filename)
            try:
                # 转换并保存为txt文件
                convert_docx_to_txt(docx_path, output_folder)
                print(f"Converted: {docx_path} -> {os.path.join(output_folder, os.path.splitext(filename)[0] + '.txt')}")
                success_count += 1
            except Exception as e:
                print(f"Error converting {docx_path}: {e}")

    if success_count > 0:
        return f"成功转换了 {success_count} 个文件。"
    else:
        return "没有成功转换任何文件。"

# 指定输入和输出文件夹路径
input_folder_path = 'D:/For_NLP/datalist'
output_folder_path = 'D:/For_NLP/for_txt'

# 执行转换
result_message = convert_all_docs_to_txt(input_folder_path, output_folder_path)
print(result_message)
