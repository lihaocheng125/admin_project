from langchain_community.document_loaders import UnstructuredWordDocumentLoader
from langchain_community.llms import OpenAI
from langchain_community.vectorstores import Pinecone
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings.openai import OpenAIEmbeddings
from pinecone import Pinecone as pcpinecone
from keys import OPENAI_API_KEY, PINECONE_API_KEY, PINECONE_API_ENV
from langchain.chains.question_answering import load_qa_chain
import streamlit as st
import os

# '''
# 下面的这部分代码是将文件夹中的word文档，上传到自己的向量数据库
# '''
# # 首先进入文件夹查看数据
# directory_path = 'D:\For_NLP\datalist'  # 这边填入你自己的数据文件所在的文件夹
# data = []
# # loop through each file in the directory
# for filename in os.listdir(directory_path):
#     # check if the file is a doc or docx file
#     # 检查所有doc以及docx后缀的文件
#     if filename.endswith(".doc") or filename.endswith(".docx"):
#         # print the file name
#         # langchain自带功能，加载word文档
#         loader = UnstructuredWordDocumentLoader(f'{directory_path}/{filename}')
#         print(loader)
#         data.append(loader.load())
# print(len(data))
# # Chunking the data into smaller pieces
# # 再用菜刀把文档分隔开，chunk_size就是我们要切多大，建议设置700及以下，因为openai有字数限制，chunk_overlap就是重复上下文多少个字
# text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=20)
# texts = []
# for i in range(len(data)):
#     print(i)
#     texts.append(text_splitter.split_documents(data[i]))
#     print(text_splitter.split_documents(data[i]))
# print(len(texts))
#
# embeddings = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)
# pc = pcpinecone(api_key=PINECONE_API_KEY)
# index_name = 'data'
# for i in range(len(texts)):
#     Pinecone.from_texts([t.page_content for t in texts[i]], embeddings, index_name=index_name)
#     print("done")
#
# # """创建网站实现问答系统"""
st.title('面向铁路公共安全的问答系统')  # 用streamlit app创建一个标题
# 创建一个输入栏可以让用户去输入问题
query = st.text_input('欢迎来到铁路公共安全的网站，您可以问我关于铁路公共安全的问题')  # 创建问答框，用户可以在网站中提问，实现交互

my_bar = st.progress(0, text='等待您的问题')  # 进度条为0，等待用户发问
# initialize search 
# 开始搜索，解答
if query:
    # 初始化pinecone数据库，与pinecone建立连接
    pc = pcpinecone(api_key=PINECONE_API_KEY)
    index_name = 'data'
    index = pc.Index(index_name)

    llm = OpenAI(temperature=0, max_tokens=-1, openai_api_key=OPENAI_API_KEY)
    # 引入langchain_community.llms中的OpenAI的模型，temperature 用于调整生成文本的创造性和随机性。max_tokens控制生成的文本的最大长度
    print('1:' + str(llm))
    my_bar.progress(10, text='正在查询我的语料库')

    embeddings = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)
    # embedding就是把文字变成数字
    print('2:' + str(embeddings))

    docsearch = Pinecone.from_existing_index('data', embedding=embeddings)
    # 调用pinecone的数据库，开始查询任务
    print('3:' + str(docsearch))

    docs = docsearch.similarity_search(query, k=3)
    # 相似度搜索
    print('4:' + str(docs))
    my_bar.progress(60, text='有点头绪了')

    chain = load_qa_chain(llm, chain_type='stuff', verbose=True)
    # 调用langchain的load qa办法，’stuff‘为一种放入openai的办法
    print('5:' + str(chain))

    my_bar.progress(90, text='可以开始生成答案了，脑细胞在燃烧')
    # 得到答案
    answer = chain.run(input_documents=docs, question=query, verbose=True)
    print('6:' + str(answer))
    my_bar.progress(100, text='好了')
    st.write(answer)
