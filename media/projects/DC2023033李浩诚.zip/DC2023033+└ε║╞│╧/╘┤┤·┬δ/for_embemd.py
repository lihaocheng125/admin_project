import os
from natsort import natsorted
from openai import OpenAI

from keys import OPENAI_API_KEY

# 替换为你的OpenAI API密钥
client = OpenAI(api_key=OPENAI_API_KEY)

# 输入和输出文件夹路径
input_folder = "D:\\For_NLP\\data_for_embedding"
output_folder = "D:\\For_NLP\\embedding_data"

# 获取文件列表并按照自然排序
file_list = natsorted(os.listdir(input_folder))

# 遍历每个文件
for file_name in file_list:
    # 构建输入文件路径
    input_file_path = os.path.join(input_folder, file_name)

    # 读取文本文件内容
    with open(input_file_path, 'r', encoding='utf-8') as file:
        text_content = file.read()

    # 使用OpenAI模型进行文本转换
        embeddings = client.embeddings.create(input=text_content, model="text-embedding-ada-002")

    # 获取文件名和扩展名
    file_base_name, file_extension = os.path.splitext(file_name)

    # 构建输出文件路径，将文件直接保存在指定文件夹中
    output_file_path = os.path.join(output_folder, f"{file_base_name}_embed{file_extension}")

    # 提取词向量并将其写入输出文件
    with open(output_file_path, 'w', encoding='utf-8') as embed_file:
        for vector in embeddings:
            embed_file.write(str(vector) + ' ')

    print(f"Processed: {output_file_path}")

print("Conversion complete.")
