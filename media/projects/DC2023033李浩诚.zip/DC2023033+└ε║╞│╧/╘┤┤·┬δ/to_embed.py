import os
from natsort import natsorted

# 输入和输出文件夹路径
input_folder = "D:\\For_NLP\\embedding_data"
output_folder = "D:\\For_NLP\\embed_data"

# 获取文件列表并按照自然排序
file_list = natsorted(os.listdir(input_folder))

# 创建输出文件夹如果不存在
os.makedirs(output_folder, exist_ok=True)

# 遍历每个文件
for file_name in file_list:
    # 构建输入文件路径
    input_file_path = os.path.join(input_folder, file_name)

    # 读取文本文件内容
    with open(input_file_path, 'r', encoding='utf-8') as file:
        original_content = file.read()

    # 提取嵌入列表
    start_index = original_content.find('embedding=[')
    end_index = original_content.find(']', start_index)
    embedding_list_str = original_content[start_index + len('embedding=['):end_index]
    embedding_list = [float(num) for num in embedding_list_str.split(',')]

    # 构建输出文件路径
    output_file_path = os.path.join(output_folder, f"{file_name}")

    # 将嵌入列表写入输出文件
    with open(output_file_path, 'w', encoding='utf-8') as embed_file:
        embed_file.write(" ".join(map(str, embedding_list)))

    print(f"已处理：{output_file_path}")

print("转换完成。")
